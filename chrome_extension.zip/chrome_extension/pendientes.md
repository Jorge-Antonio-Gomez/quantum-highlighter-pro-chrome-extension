# Pendientes

## Traducciones

- [ ] Crear archivos de localización (`_locales/messages.json`) para la extensión (25/07/2025)

## Sidebar

- [ ] Integración de edición de comentarios en la barra lateral.
